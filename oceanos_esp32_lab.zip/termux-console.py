#!/usr/bin/env python3
import sys
import time
import serial

def main():
    port = sys.argv[1] if len(sys.argv) > 1 else "/dev/ttyUSB0"
    baud = int(sys.argv[2]) if len(sys.argv) > 2 else 115200

    print(f"[OceanOS Termux] opening {port} @ {baud}")
    ser = serial.Serial(port, baudrate=baud, timeout=0.1)
    time.sleep(1)

    try:
        while True:
            # Drain device output
            data = ser.read(4096)
            if data:
                sys.stdout.write(data.decode(errors="replace"))
                sys.stdout.flush()

            # Read one user line without requiring a full-screen TUI.
            if sys.stdin in []:
                pass

            import select
            ready, _, _ = select.select([sys.stdin], [], [], 0.05)
            if ready:
                line = sys.stdin.readline()
                if line == "":
                    break
                ser.write(line.encode())
    except KeyboardInterrupt:
        pass
    finally:
        ser.close()

if __name__ == "__main__":
    main()
