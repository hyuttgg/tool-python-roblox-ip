# OceanOS ESP32 architecture

## Mapping from os-tutorial

| os-tutorial idea | ESP32 implementation |
|---|---|
| Boot sector | ESP-IDF bootloader/ROM boot path |
| 16-bit real mode | Not applicable |
| 32-bit protected mode | ESP32 CPU architecture + ESP-IDF startup |
| GDT | Not applicable as x86 GDT concept |
| VGA driver | UART console; optional display driver can be added |
| Keyboard driver | UART input / GPIO input |
| Interrupts | ESP-IDF ISR + FreeRTOS queue |
| Timer | FreeRTOS tick + esp_timer |
| malloc | ESP-IDF heap allocator |
| Filesystem | SPIFFS through VFS |
| Shell | OceanOS command interpreter |
| Processes | FreeRTOS tasks |
| Scheduler | FreeRTOS scheduler |

## Core algorithms

### Memory
- Heap capability queries
- Largest free block
- Minimum free watermark

### Scheduling
- FreeRTOS task scheduler
- Priority based task dispatch

### Routing/graphs
- Bellman-Ford
- Dijkstra

### Utilities
- FNV-1a hashing
- Command tokenization
- Queue-based ISR event dispatch

## Next expansion

1. Add FATFS/SD card as a second drive `/sd`.
2. Add Wi-Fi network manager.
3. Add TCP socket service.
4. Add block-device abstraction.
5. Add a custom virtual filesystem layer.
6. Add process-like user jobs above FreeRTOS tasks.
7. Add a framebuffer/SSD1306 terminal driver.
8. Add signed OTA update and rollback.
