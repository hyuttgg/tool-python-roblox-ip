#include "shell.h"
#include "drivers.h"
#include "storage.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "oceanos";

void app_main(void)
{
    ESP_LOGI(TAG, "booting OceanOS");

    drivers_init();
    if (!storage_init()) {
        ESP_LOGW(TAG, "filesystem unavailable");
    }

    shell_start();
}
