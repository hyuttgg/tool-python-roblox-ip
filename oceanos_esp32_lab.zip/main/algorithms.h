#pragma once
#include <stddef.h>

#define ROUTE_INF 1000000
#define ROUTE_N 6

typedef struct {
    int from;
    int to;
    int cost;
} route_edge_t;

typedef struct {
    int n;
    int dist[ROUTE_N];
    int prev[ROUTE_N];
} route_result_t;

void algorithms_demo(void);
void bellman_ford(const route_edge_t *edges, size_t edge_count, int n, int src, route_result_t *out);
void dijkstra_matrix(const int matrix[ROUTE_N][ROUTE_N], int n, int src, route_result_t *out);
unsigned long long fnv1a_hash(const char *s);
