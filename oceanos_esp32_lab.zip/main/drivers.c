#include "drivers.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"

static const char *TAG = "drivers";
static QueueHandle_t gpio_evt_queue;

static void IRAM_ATTR gpio_isr(void *arg)
{
    uint32_t pin = (uint32_t)arg;
    BaseType_t hp = pdFALSE;
    xQueueSendFromISR(gpio_evt_queue, &pin, &hp);
    if (hp) portYIELD_FROM_ISR();
}

static void gpio_event_task(void *arg)
{
    uint32_t pin;
    while (1) {
        if (xQueueReceive(gpio_evt_queue, &pin, portMAX_DELAY)) {
            ESP_LOGI(TAG, "GPIO IRQ pin=%lu", (unsigned long)pin);
        }
    }
}

void drivers_init(void)
{
    gpio_evt_queue = xQueueCreate(8, sizeof(uint32_t));

    xTaskCreate(gpio_event_task, "gpio_evt", 2048, NULL, 5, NULL);

    /* Safe default: onboard LED is commonly GPIO2 on classic DevKit,
       but users should verify their board before connecting hardware. */
    gpio_config_t out = {
        .pin_bit_mask = 1ULL << 2,
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&out);
    gpio_set_level(2, 0);
}

void gpio_write(uint8_t pin, uint8_t level)
{
    gpio_set_direction(pin, GPIO_MODE_OUTPUT);
    gpio_set_level(pin, level ? 1 : 0);
}

void gpio_input_irq_start(uint8_t pin)
{
    gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << pin,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_ANYEDGE
    };
    gpio_config(&cfg);
    gpio_install_isr_service(ESP_INTR_FLAG_IRAM);
    gpio_isr_handler_add(pin, gpio_isr, (void *)(uintptr_t)pin);
}
