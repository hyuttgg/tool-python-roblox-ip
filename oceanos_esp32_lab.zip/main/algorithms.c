#include "algorithms.h"
#include <stdio.h>
#include <string.h>

unsigned long long fnv1a_hash(const char *s)
{
    const unsigned long long FNV_OFFSET = 1469598103934665603ULL;
    const unsigned long long FNV_PRIME  = 1099511628211ULL;
    unsigned long long h = FNV_OFFSET;
    while (*s) {
        h ^= (unsigned char)*s++;
        h *= FNV_PRIME;
    }
    return h;
}

void bellman_ford(const route_edge_t *edges, size_t edge_count, int n, int src, route_result_t *out)
{
    for (int i = 0; i < n; ++i) {
        out->dist[i] = ROUTE_INF;
        out->prev[i] = -1;
    }
    out->dist[src] = 0;

    for (int pass = 0; pass < n - 1; ++pass) {
        int changed = 0;
        for (size_t i = 0; i < edge_count; ++i) {
            const route_edge_t *e = &edges[i];
            if (e->from < 0 || e->from >= n || e->to < 0 || e->to >= n)
                continue;
            if (out->dist[e->from] == ROUTE_INF)
                continue;

            int cand = out->dist[e->from] + e->cost;
            if (cand < out->dist[e->to]) {
                out->dist[e->to] = cand;
                out->prev[e->to] = e->from;
                changed = 1;
            }
        }
        if (!changed)
            break;
    }
}

void dijkstra_matrix(const int matrix[ROUTE_N][ROUTE_N], int n, int src, route_result_t *out)
{
    int used[ROUTE_N] = {0};

    for (int i = 0; i < n; ++i) {
        out->dist[i] = ROUTE_INF;
        out->prev[i] = -1;
    }
    out->dist[src] = 0;

    for (int step = 0; step < n; ++step) {
        int u = -1;
        for (int i = 0; i < n; ++i) {
            if (!used[i] && (u == -1 || out->dist[i] < out->dist[u]))
                u = i;
        }
        if (u == -1 || out->dist[u] == ROUTE_INF)
            break;

        used[u] = 1;

        for (int v = 0; v < n; ++v) {
            int w = matrix[u][v];
            if (w <= 0 || used[v])
                continue;
            int cand = out->dist[u] + w;
            if (cand < out->dist[v]) {
                out->dist[v] = cand;
                out->prev[v] = u;
            }
        }
    }
}

void algorithms_demo(void)
{
    static const route_edge_t edges[] = {
        {0,1,4}, {0,2,2}, {1,2,1}, {1,3,5},
        {2,3,8}, {2,4,10}, {3,4,2}, {4,5,3}
    };
    route_result_t bf = {0};
    bellman_ford(edges, sizeof(edges)/sizeof(edges[0]), ROUTE_N, 0, &bf);

    printf("Bellman-Ford from node 0:\n");
    for (int i = 0; i < ROUTE_N; ++i)
        printf("  0 -> %d = %d\n", i, bf.dist[i]);

    static const int matrix[ROUTE_N][ROUTE_N] = {
        {0,4,2,0,0,0},
        {4,0,1,5,0,0},
        {2,1,0,8,10,0},
        {0,5,8,0,2,0},
        {0,0,10,2,0,3},
        {0,0,0,0,3,0}
    };
    route_result_t dj = {0};
    dijkstra_matrix(matrix, ROUTE_N, 0, &dj);

    printf("Dijkstra from node 0:\n");
    for (int i = 0; i < ROUTE_N; ++i)
        printf("  0 -> %d = %d\n", i, dj.dist[i]);
}
