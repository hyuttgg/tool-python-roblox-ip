#include "storage.h"
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include "esp_log.h"
#include "esp_spiffs.h"

static const char *TAG = "storage";
static const char *BASE = "/data";

bool storage_init(void)
{
    esp_vfs_spiffs_conf_t conf = {
        .base_path = BASE,
        .partition_label = NULL,
        .max_files = 8,
        .format_if_mount_failed = true
    };

    esp_err_t err = esp_vfs_spiffs_register(&conf);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "SPIFFS mount failed: %s", esp_err_to_name(err));
        return false;
    }

    size_t total = 0, used = 0;
    err = esp_spiffs_info(NULL, &total, &used);
    if (err == ESP_OK)
        ESP_LOGI(TAG, "SPIFFS total=%u used=%u", (unsigned)total, (unsigned)used);
    return true;
}

void storage_ls(void)
{
    DIR *d = opendir(BASE);
    if (!d) {
        printf("ls: cannot open %s\n", BASE);
        return;
    }

    struct dirent *e;
    while ((e = readdir(d)) != NULL)
        printf("%s\n", e->d_name);

    closedir(d);
}

static void make_path(char *out, size_t out_sz, const char *name)
{
    snprintf(out, out_sz, "%s/%s", BASE, name);
}

void storage_cat(const char *name)
{
    char path[128];
    make_path(path, sizeof(path), name);

    FILE *f = fopen(path, "r");
    if (!f) {
        printf("cat: %s: not found\n", name);
        return;
    }

    char buf[128];
    while (fgets(buf, sizeof(buf), f))
        fputs(buf, stdout);

    fclose(f);
}

void storage_write(const char *name, const char *data)
{
    char path[128];
    make_path(path, sizeof(path), name);

    FILE *f = fopen(path, "w");
    if (!f) {
        printf("write: cannot open %s\n", name);
        return;
    }

    fputs(data, f);
    fclose(f);
    printf("written %s\n", name);
}
