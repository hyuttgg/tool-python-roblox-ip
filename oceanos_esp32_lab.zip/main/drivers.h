#pragma once
#include <stdint.h>
#include "driver/gpio.h"

void drivers_init(void);
void gpio_write(uint8_t pin, uint8_t level);
void gpio_input_irq_start(uint8_t pin);
