#include "shell.h"
#include "algorithms.h"
#include "drivers.h"
#include "storage.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>

#include "esp_chip_info.h"
#include "esp_flash.h"
#include "esp_system.h"
#include "esp_heap_caps.h"
#include "esp_idf_version.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define LINE_MAX 256

static void print_help(void)
{
    puts("OceanOS commands:");
    puts("  help                  - command list");
    puts("  sysinfo               - chip + firmware info");
    puts("  mem                   - heap information");
    puts("  ps                    - task count");
    puts("  uptime                - milliseconds since boot");
    puts("  mount                 - filesystem info");
    puts("  ls                    - list /data");
    puts("  cat <file>            - read file");
    puts("  write <file> <text>   - write file");
    puts("  hash <text>           - FNV-1a hash");
    puts("  route                 - routing demo");
    puts("  bf                    - Bellman-Ford demo");
    puts("  dijkstra              - Dijkstra demo");
    puts("  gpio <pin> <0|1>      - output GPIO");
    puts("  gpioirq <pin>         - attach GPIO edge IRQ");
    puts("  clear                 - clear terminal");
    puts("  reboot                - restart ESP32");
}

static void cmd_sysinfo(void)
{
    esp_chip_info_t chip;
    esp_chip_info(&chip);

    uint32_t flash_size = 0;
    esp_flash_get_size(NULL, &flash_size);

    printf("OceanOS ESP32\n");
    printf("IDF: %s\n", esp_get_idf_version());
    printf("Cores: %d\n", chip.cores);
    printf("Revision: %d\n", chip.revision);
    printf("Features: WiFi=%s BT=%s BLE=%s\n",
           (chip.features & CHIP_FEATURE_WIFI_BGN) ? "yes" : "no",
           (chip.features & CHIP_FEATURE_BT) ? "yes" : "no",
           (chip.features & CHIP_FEATURE_BLE) ? "yes" : "no");
    printf("Flash: %" PRIu32 " bytes\n", flash_size);
}

static void cmd_mem(void)
{
    multi_heap_info_t info;
    heap_caps_get_info(&info, MALLOC_CAP_8BIT);

    printf("free=%u\n", (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT));
    printf("largest=%u\n", (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT));
    printf("minimum=%u\n", (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_8BIT));
    printf("alloc_count=%u\n", (unsigned)info.total_allocated_bytes);
}

static void cmd_ps(void)
{
    UBaseType_t n = uxTaskGetNumberOfTasks();
    printf("tasks=%u\n", (unsigned)n);
}

static void cmd_mount(void)
{
    size_t total = 0, used = 0;
    if (esp_spiffs_info(NULL, &total, &used) == ESP_OK)
        printf("/data SPIFFS total=%u used=%u free=%u\n",
               (unsigned)total, (unsigned)used, (unsigned)(total - used));
    else
        puts("/data unavailable");
}

static void cmd_routes(const char *alg)
{
    if (!strcmp(alg, "bf") || !strcmp(alg, "route"))
        algorithms_demo();
    else if (!strcmp(alg, "dijkstra"))
        algorithms_demo();
}

static void process_line(char *line)
{
    char *save = NULL;
    char *cmd = strtok_r(line, " \t", &save);
    if (!cmd) return;

    if (!strcmp(cmd, "help")) {
        print_help();
    } else if (!strcmp(cmd, "sysinfo")) {
        cmd_sysinfo();
    } else if (!strcmp(cmd, "mem")) {
        cmd_mem();
    } else if (!strcmp(cmd, "ps")) {
        cmd_ps();
    } else if (!strcmp(cmd, "uptime")) {
        printf("%" PRIu64 " ms\n", esp_timer_get_time() / 1000ULL);
    } else if (!strcmp(cmd, "mount")) {
        cmd_mount();
    } else if (!strcmp(cmd, "ls")) {
        storage_ls();
    } else if (!strcmp(cmd, "cat")) {
        char *name = strtok_r(NULL, " \t", &save);
        if (name) storage_cat(name);
        else puts("usage: cat <file>");
    } else if (!strcmp(cmd, "write")) {
        char *name = strtok_r(NULL, " \t", &save);
        char *text = save;
        if (name && text) {
            while (*text == ' ' || *text == '\t') ++text;
            storage_write(name, text);
        } else {
            puts("usage: write <file> <text>");
        }
    } else if (!strcmp(cmd, "hash")) {
        char *text = save;
        while (text && (*text == ' ' || *text == '\t')) ++text;
        if (text && *text)
            printf("%016llx\n", fnv1a_hash(text));
        else
            puts("usage: hash <text>");
    } else if (!strcmp(cmd, "bf")) {
        cmd_routes("bf");
    } else if (!strcmp(cmd, "dijkstra")) {
        cmd_routes("dijkstra");
    } else if (!strcmp(cmd, "route")) {
        cmd_routes("route");
    } else if (!strcmp(cmd, "gpio")) {
        char *p = strtok_r(NULL, " \t", &save);
        char *l = strtok_r(NULL, " \t", &save);
        if (p && l) gpio_write((uint8_t)atoi(p), (uint8_t)atoi(l));
        else puts("usage: gpio <pin> <0|1>");
    } else if (!strcmp(cmd, "gpioirq")) {
        char *p = strtok_r(NULL, " \t", &save);
        if (p) gpio_input_irq_start((uint8_t)atoi(p));
        else puts("usage: gpioirq <pin>");
    } else if (!strcmp(cmd, "clear")) {
        printf("\033[2J\033[H");
    } else if (!strcmp(cmd, "reboot")) {
        puts("rebooting...");
        vTaskDelay(pdMS_TO_TICKS(200));
        esp_restart();
    } else {
        printf("unknown command: %s\n", cmd);
    }
}

void shell_start(void)
{
    char line[LINE_MAX];

    puts("");
    puts("========================================");
    puts("          OCEANOS FOR ESP32");
    puts("   OS-like firmware / Termux console");
    puts("========================================");
    puts("type 'help'");

    while (1) {
        printf("oceanos> ");
        fflush(stdout);

        if (!fgets(line, sizeof(line), stdin)) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }

        line[strcspn(line, "\r\n")] = 0;
        process_line(line);
    }
}
