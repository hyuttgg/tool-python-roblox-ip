#pragma once
#include <stdbool.h>

bool storage_init(void);
void storage_ls(void);
void storage_cat(const char *name);
void storage_write(const char *name, const char *data);
