# ESP32 OS Lab

Một firmware "OS-like" lấy cảm hứng từ cfenollosa/os-tutorial nhưng thiết kế lại cho ESP32/ESP-IDF.

## Ý tưởng

`os-tutorial` là tutorial OS cho môi trường x86/BIOS cũ, có boot sector, 16->32-bit, GDT, interrupt, shell, malloc...
ESP32 không chạy theo mô hình BIOS đó. Project này giữ lại các mục tiêu học tập tương ứng:

- Kernel runtime: FreeRTOS task/scheduler
- Console/TTY: UART + shell
- Memory manager: ESP-IDF heap + thống kê/diagnostics
- Filesystem/drive: SPIFFS trên partition `/data`, đi qua VFS
- Drivers: GPIO + UART console
- IPC: FreeRTOS queues
- Interrupt model: GPIO ISR -> queue -> task
- Algorithms: Bellman-Ford, Dijkstra, ring buffer, FNV-1a hash
- System utilities: sysinfo, mem, ps, uptime, mount, file I/O
- Termux console: Python serial terminal
- Flash helper: `termux.sh`

## Kiến trúc

ESP32 ROM/bootloader
        |
        v
ESP-IDF startup
        |
        v
FreeRTOS
  +-----+-----------------+----------------+
  |     |                 |                |
Shell  Driver           Storage         Monitor
  |     |                 |                |
UART   GPIO ISR         VFS/SPIFFS      heap/task
  |
Commands
  |
Algorithms
  +-- Bellman-Ford
  +-- Dijkstra
  +-- Hash
  +-- Ring buffer

## Build

Cài ESP-IDF rồi:

```bash
idf.py set-target esp32
idf.py build
idf.py flash monitor
```

Mặc định console UART 115200.

## Termux

Trong Termux:

```bash
pkg update
pkg install python git
pip install pyserial
python termux-console.py /dev/ttyUSB0
```

Hoặc:

```bash
chmod +x termux.sh
./termux.sh /dev/ttyUSB0
```

Tên cổng có thể là `/dev/ttyUSB0` hoặc `/dev/ttyACM0` tùy USB-UART.

## Shell demo

```text
oceanos> help
oceanos> sysinfo
oceanos> mem
oceanos> ps
oceanos> uptime
oceanos> mount
oceanos> ls
oceanos> write hello.txt hello esp32
oceanos> cat hello.txt
oceanos> hash hello
oceanos> route
oceanos> bf
oceanos> dijkstra
oceanos> gpio 2 1
oceanos> gpio 2 0
oceanos> reboot
```

## Ghi chú

Đây là firmware giáo dục kiểu microkernel/RTOS shell, không phải một kernel bare-metal thay thế hoàn toàn ESP-IDF boot/runtime.
