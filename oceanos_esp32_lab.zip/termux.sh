#!/data/data/com.termux/files/usr/bin/bash
set -e

PORT="${1:-/dev/ttyUSB0}"

echo "[OceanOS] port=$PORT"
echo "[OceanOS] Install dependencies if needed:"
echo "  pkg install python"
echo "  pip install pyserial"
echo
python termux-console.py "$PORT" 115200
